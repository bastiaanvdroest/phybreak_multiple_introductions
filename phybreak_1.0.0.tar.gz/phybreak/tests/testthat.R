library(testthat)
library(phybreak)

test_check("phybreak")
